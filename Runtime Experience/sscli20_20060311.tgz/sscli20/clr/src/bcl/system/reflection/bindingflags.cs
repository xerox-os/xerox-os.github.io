// ==++==
// 
//   
//    Copyright (c) 2006 Microsoft Corporation.  All rights reserved.
//   
//    The use and distribution terms for this software are contained in the file
//    named license.txt, which can be found in the root of this distribution.
//    By using this software in any fashion, you are agreeing to be bound by the
//    terms of this license.
//   
//    You must not remove this notice, or any other, from this software.
//   
// 
// ==--==
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//
// BindingFlags are a set of flags that control the binding and invocation process
//	in Reflection.  There are two processes.  The first is selection of a Member which
//	is the binding phase.  The second, is invocation.  These flags control how this
//	process works.
//
// Date: June 99
//
namespace System.Reflection {
    
	using System;
    [Flags, Serializable]
[System.Runtime.InteropServices.ComVisible(true)]
    public enum BindingFlags
    {

		// NOTES: We have lookup masks defined in RuntimeType and Activator.  If we
		//	change the lookup values then these masks may need to change also.

        // a place holder for no flag specifed
    	Default             = 0x00,		

    	// These flags indicate what to search for when binding
    	IgnoreCase			= 0x01,		// Ignore the case of Names while searching
 		DeclaredOnly		= 0x02,		// Only look at the members declared on the Type
		Instance			= 0x04,		// Include Instance members in search
    	Static				= 0x08,		// Include Static members in search
		Public				= 0x10,		// Include Public members in search
    	NonPublic			= 0x20,		// Include Non-Public members in search
		FlattenHierarchy	= 0x40,		// Rollup the statics into the class.
   
    	// These flags are used by InvokeMember to determine
    	// what type of member we are trying to Invoke.
    	// BindingAccess = 0xFF00;
    	InvokeMethod		= 0x0100,
    	CreateInstance		= 0x0200,
    	GetField			= 0x0400,
    	SetField			= 0x0800,
    	GetProperty			= 0x1000,
    	SetProperty			= 0x2000,

		// These flags are also used by InvokeMember but they should only
		// be used when calling InvokeMember on a COM object.
		PutDispProperty     = 0x4000,
		PutRefDispProperty  = 0x8000,

    	ExactBinding		= 0x010000,		// Bind with Exact Type matching, No Change type
    	SuppressChangeType		= 0x020000,

    	// DefaultValueBinding will return the set of methods having ArgCount or 
    	//	more parameters.  This is used for default values, etc.
    	OptionalParamBinding		= 0x040000,

		// These are a couple of misc attributes used
    	IgnoreReturn	= 0x01000000,	// This is used in COM Interop
     }
}
