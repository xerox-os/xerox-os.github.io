// ==++==
// 
//   
//    Copyright (c) 2006 Microsoft Corporation.  All rights reserved.
//   
//    The use and distribution terms for this software are contained in the file
//    named license.txt, which can be found in the root of this distribution.
//    By using this software in any fashion, you are agreeing to be bound by the
//    terms of this license.
//   
//    You must not remove this notice, or any other, from this software.
//   
// 
// ==--==
namespace System.Reflection {
    
	using System;
    // This Enum matchs the CorFieldAttr defined in CorHdr.h
	[Serializable()] 
	[Flags()]
[System.Runtime.InteropServices.ComVisible(true)]
    public enum FieldAttributes
    {
    	// member access mask - Use this mask to retrieve accessibility information.
    	FieldAccessMask 	=	0x0007,
    	PrivateScope 		=	0x0000,	// Member not referenceable.
        Private   			=	0x0001,	// Accessible only by the parent type.  
    	FamANDAssem 		=	0x0002,	// Accessible by sub-types only in this Assembly.
    	Assembly			=	0x0003,	// Accessibly by anyone in the Assembly.
        Family				=	0x0004,	// Accessible only by type and sub-types.    
    	FamORAssem 			=	0x0005,	// Accessibly by sub-types anywhere, plus anyone in assembly.
        Public    			=	0x0006,	// Accessibly by anyone who has visibility to this scope.    
    	// end member access mask
    
        // field contract attributes.
    	Static				=	0x0010,		// Defined on type, else per instance.
        InitOnly  			=  	0x0020,     // Field may only be initialized, not written to after init.
        Literal				=	0x0040,		// Value is compile time constant.
    	NotSerialized		=	0x0080,		// Field does not have to be serialized when type is remoted.
    	
        SpecialName			=   0x0200,     // field is special.  Name describes how.
    
    	// interop attributes
    	PinvokeImpl 		= 	0x2000,		// Implementation is forwarded through pinvoke.

		// Reserved flags for runtime use only.
		ReservedMask              =   0x9500,
		RTSpecialName             =   0x0400,     // Runtime(metadata internal APIs) should check name encoding.
		HasFieldMarshal           =   0x1000,     // Field has marshalling information.
		HasDefault                =   0x8000,     // Field has default.
		HasFieldRVA               =   0x0100,     // Field has RVA.
    }
}
