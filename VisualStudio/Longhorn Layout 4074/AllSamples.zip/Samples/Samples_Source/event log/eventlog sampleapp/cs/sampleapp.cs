//---------------------------------------------------------------------
//  This file is part of the Microsoft .NET Framework SDK Code Samples.
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
// 
//This source code is intended only as a supplement to Microsoft
//Development Tools and/or on-line documentation.  See these other
//materials for detailed information regarding Microsoft code samples.
// 
//THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
//KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
//PARTICULAR PURPOSE.
//---------------------------------------------------------------------

using System;
using System.Diagnostics.Events;


namespace Microsoft.SampleApp
{
	public class Sample
	{
		static public void Main(string[] args)
		{

			using(EventLog App = new EventLog("Applications/SampleApp/Operational", ".", "SampleApp"))
			{
				App.WriteEvent(
					1000,	// eventID whose definition is in manifest
					new object[] {"MyPrinter02"});

				App.WriteEvent(
					1001,	// eventID whose definition is in manifest
					new object[] {"MyPrinter03"});
			}

			Console.WriteLine("Success!");

		}
	}
}