//---------------------------------------------------------------------
//  This file is part of the Microsoft .NET Framework SDK Code Samples.
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
// 
//This source code is intended only as a supplement to Microsoft
//Development Tools and/or on-line documentation.  See these other
//materials for detailed information regarding Microsoft code samples.
// 
//THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
//KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
//PARTICULAR PURPOSE.
//---------------------------------------------------------------------
using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Permissions;
using System.Runtime.InteropServices;

//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: SecurityPermission (SecurityAction.RequestMinimum, UnmanagedCode = true)]
[assembly: ComVisible (false)]
[assembly: CLSCompliant (true)]
[assembly:AssemblyTitleAttribute("Language Capabilities sample")]
[assembly:AssemblyDescriptionAttribute("")]
[assembly:AssemblyConfigurationAttribute("")]
[assembly:AssemblyCompanyAttribute("Microsoft Corporation")]
[assembly:AssemblyProductAttribute("NLG SDK Sample")]
[assembly:AssemblyCopyrightAttribute("Copyright 2004 All Rights Reserved")]
[assembly:AssemblyTrademarkAttribute("")]
[assembly:AssemblyCultureAttribute("")]        

//
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the value or you can default the Revision and Build Numbers 
// by using the '' as shown below:

[assembly:AssemblyVersionAttribute("1.0.0.*")]

//
// In order to sign your assembly you must specify a key to use. Refer to the 
// Microsoft .NET Framework documentation for more information on assembly signing.
//
// Use the attributes below to control which key is used for signing. 
//
// Notes: 
//   () If no key is specified, the assembly is not signed.
//   () KeyName refers to a key that has been installed in the Crypto Service
//       Provider (CSP) on your machine. KeyFile refers to a file which contains
//       a key.
//   () If the KeyFile and the KeyName values are both specified, the 
//       following processing occurs:
//       (1) If the KeyName can be found in the CSP, that key is used.
//       (2) If the KeyName does not exist and the KeyFile does exist, the key 
//           in the KeyFile is installed into the CSP and used.
//   () In order to create a KeyFile, you can use the sn.exe (Strong Name) utility.
//        When specifying the KeyFile, the location of the KeyFile should be
//        relative to the project directory.
//   () Delay Signing is an advanced option - see the Microsoft .NET Framework
//       documentation for more information on this.
//
[assembly:AssemblyDelaySignAttribute(false)]
[assembly:AssemblyKeyFileAttribute("")]
[assembly:AssemblyKeyNameAttribute("")]

